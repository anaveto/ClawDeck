"""Hardware detection: which Claw this is and which control paths the kernel exposes.

One table, one row per model. A new Claw is one new row. Everything else in ClawDeck asks this module for
capabilities instead of hard-coding paths, so Lunar Lake and Meteor Lake Claws (and, with a new backend row, AMD
handhelds) get the same features where the kernel offers them.

Sources: Handheld Daemon's device table (hhd/device/claw/const.py) for the DMI product names and button layout, its
MSI adjustor driver for the TDP firmware attributes, PowerControl for the Intel xe clock paths.
"""
from __future__ import annotations

import glob
import os
import platform
import re
import subprocess
from dataclasses import dataclass, field, asdict

from . import sysfs

# ---- the model table -------------------------------------------------------------------------------------------------
# DMI board name (/sys/class/dmi/id/board_name, the MSI board id) -> model facts that the kernel does not tell us.
# The product name is a marketing string on new Claws ("Claw 8 EX AI+ CG3EM Launch Pack" on the EX), so the board id
# is matched first; older firmware put the board id in product_name, which is still tried second.
MODELS: dict[str, dict] = {
    "MS-1T41": {"name": "MSI Claw A1M", "soc": "Meteor Lake", "gpu": "Arc (Xe-LPG)", "xmx": False,
                "tdp": {"min": 8, "battery_max": 35, "plugged_max": 43, "sppt_max": 45}, "panel_hz": [60, 120]},
    "MS-1T42": {"name": "MSI Claw 7 AI+", "soc": "Lunar Lake", "gpu": "Arc 140V (Xe2)", "xmx": True,
                "tdp": {"min": 8, "battery_max": 30, "plugged_max": 30, "sppt_max": 37}, "panel_hz": [60, 120]},
    "MS-1T52": {"name": "MSI Claw 8 AI+", "soc": "Lunar Lake", "gpu": "Arc 140V (Xe2)", "xmx": True,
                "tdp": {"min": 8, "battery_max": 30, "plugged_max": 30, "sppt_max": 37}, "panel_hz": [60, 120]},
    # the Arc G3 version (Arc B370, 10 Xe3 cores; Oct 2026) is believed to share the board id: not confirmed yet
    "MS-1T91": {"name": "MSI Claw 8 EX AI+", "soc": "Panther Lake", "gpu": "Arc B390 / B370 (Xe3)", "xmx": True,
                "tdp": {"min": 8, "battery_max": 35, "plugged_max": 35, "sppt_max": 45}, "panel_hz": [60, 120],
                "vrr": [30, 120]},
    "MS-1T8K": {"name": "MSI Claw A8", "soc": "AMD Ryzen Z2 Extreme", "gpu": "Radeon 890M", "xmx": False,
                "tdp": {"min": 7, "battery_max": 35, "plugged_max": 35, "sppt_max": 40}, "panel_hz": [60, 120]},
    # ONEXPLAYER 3 (ONE-NETBOOK): DMI board and product "ONEXPLAYER 3". Panther Lake like the Claw 8 EX, an 8.8"
    # 1920x1200 144 Hz OLED. TDP 3-40 W sustained, 42 W boost through the same RAPL limits (OXP3 users' Decky
    # plugins, 2026-10/11); the xess-xmx-linux driver was developed on one. Not tested by us: beta.
    "ONEXPLAYER 3": {"name": "ONEXPLAYER 3", "vendor": "oxp", "beta": True, "soc": "Panther Lake", "gpu": "Arc B390 (Xe3)",
                     "xmx": True, "tdp": {"min": 5, "battery_max": 35, "plugged_max": 40, "sppt_max": 42},
                     "panel_hz": [60, 144], "oled": True, "oled_hdr": True},
    # OneXPlayer X1 Air (Lunar Lake, 10.95" 120 Hz LCD): DMI board "ONEXPLAYER X1Air" (Handheld Daemon's list). The
    # kernel's oxpec driver gives fan and charge limit (oxp_x1). Not tested by us: beta.
    "ONEXPLAYER X1Air": {"name": "OneXPlayer X1 Air", "vendor": "oxp", "beta": True, "soc": "Lunar Lake",
                         "gpu": "Arc 140V / 130V (Xe2)", "xmx": True,
                         "tdp": {"min": 8, "battery_max": 30, "plugged_max": 30, "sppt_max": 37}, "panel_hz": [60, 120]},
    # Acer Predator Atlas 8 (PA08-I51; Arc G3 or G3 Extreme, 8" 1920x1200 48-120 Hz; US Nov 2026): DMI sys_vendor
    # "Acer", product "Predator PA08-I51" (Bazzite #6052). Linux has no fan or charge-limit driver for it yet, so ClawDeck
    # gives it TDP (RAPL; Acer documents 8-40 W sustained), the XMX driver and the games. Not tested by us: beta.
    "Predator PA08-I51": {"name": "Acer Predator Atlas 8", "vendor": "acer", "beta": True, "soc": "Panther Lake",
                          "gpu": "Arc B390 / B370 (Xe3)", "xmx": True,
                          "tdp": {"min": 8, "battery_max": 30, "plugged_max": 40, "sppt_max": 40}, "panel_hz": [60, 120]},
}
for _row in MODELS.values():
    _row.setdefault("vendor", "msi")

# recommended profiles per model, watts (TDP = PL1 sustained; the boost limit PL2 follows from it). Six steps, lowest
# to highest power (HARDWARE-FINDINGS §17): battery saver and battery (longest play time), balanced (heavier games,
# still unplugged), performance (plugged in, handheld), plugged (heavy games on the charger) and max (the firmware
# ceiling, docked). Why these numbers: Intel's Lunar and Panther Lake chips get most of their frames by about 12-17 W
# and little more per watt above that (Notebookcheck's Claw 8 AI+ runs: about 8 h 40 min at 8 W, 3 h 40 min at 17 W,
# 2 h 20 min at 25 W), so battery play belongs at 10-17 W and 25 W+ is for the charger. Starting points until
# measurements from a Claw replace them; set_tdp clamps each to the model's own limits.
_SIX_STEPS = {
    # gpu_power_profile: xe's efficiency hint (§22.3); power_saving prefers the efficient clock and ramps up slower
    "saver":       {"tdp": 10, "cpu_max_pct": 60,  "gpu_min_mhz": None, "epp": "power", "gpu_power_profile": "power_saving", "note": "2D, indie and old games; the longest play time"},
    "battery":     {"tdp": 12, "cpu_max_pct": 70,  "gpu_min_mhz": None, "epp": "balance_power", "gpu_power_profile": "power_saving", "note": "light games, long trips"},
    "balanced":    {"tdp": 17, "cpu_max_pct": 85,  "gpu_min_mhz": None, "epp": "balance_power", "gpu_power_profile": "base", "note": "heavier games, still on battery"},
    "performance": {"tdp": 25, "cpu_max_pct": 100, "gpu_min_mhz": None, "epp": "balance_performance", "gpu_power_profile": "base", "note": "plugged in, handheld"},
    "plugged":     {"tdp": 30, "cpu_max_pct": 100, "gpu_min_mhz": None, "epp": "balance_performance", "gpu_power_profile": "base", "note": "heavy games on the charger; warm"},
    "max":         {"tdp": 35, "cpu_max_pct": 100, "gpu_min_mhz": None, "epp": "performance", "gpu_power_profile": "base", "note": "the firmware ceiling, docked; fans audible"},
}
PROFILES: dict[str, dict[str, dict]] = {
    "default": _SIX_STEPS,
    "MS-1T91": {**_SIX_STEPS,
                "max": dict(_SIX_STEPS["max"], note="35 W sustained / 45 W boost, docked; fans audible")},
}
# names saved by earlier versions (settings.json, per-game profiles) that map onto today's
PROFILE_ALIASES = {"dock": "max"}


def profile_name(name: str | None) -> str | None:
    return PROFILE_ALIASES.get(name, name) if name else name


@dataclass
class Paths:
    """Control paths discovered on this machine. None = not available on this kernel/model."""
    # Intel xe / i915 GPU clocks (PowerControl's discovery, extended with cur/rp0/rpe/rpn)
    gpu_card: str | None = None
    gpu_min_freq: str | None = None
    gpu_max_freq: str | None = None
    gpu_cur_freq: str | None = None
    gpu_rp0_freq: str | None = None      # hardware maximum
    gpu_rpe_freq: str | None = None      # efficient frequency
    gpu_rpn_freq: str | None = None      # hardware minimum
    gpu_power_profile: str | None = None # xe SLPC efficiency hint: "[base] power_saving" (findings §22.3)
    gpu_busy: str | None = None          # not exposed by xe; PowerStation's GpuBusyPercent is read instead (shadowblip.py)
    # CPU
    cpu_max_perf_pct: str | None = None
    cpu_min_perf_pct: str | None = None
    cpu_no_turbo: str | None = None
    cpu_boost: str | None = None         # cpufreq boost (AMD / acpi-cpufreq)
    cpu_governor: list[str] = field(default_factory=list)
    cpu_epp: list[str] = field(default_factory=list)   # intel_pstate energy_performance_preference, one per CPU
    # package power
    rapl_package: str | None = None      # intel-rapl-mmio:0 or intel-rapl:0 directory
    rapl_pl1: str | None = None
    rapl_pl2: str | None = None
    rapl_pl1_max: str | None = None      # constraint_N_max_power_uw of PL1: what the firmware says the chip sustains
    rapl_pl1_window: str | None = None   # constraint_N_time_window_us of PL1 (tau: the average PL1 is enforced over)
    rapl_energy: str | None = None       # energy_uj for power readings
    rapl_alt_pl1: str | None = None      # the other RAPL interface's limits (MSR when MMIO is primary): raised so it never caps
    rapl_alt_pl2: str | None = None
    # MSI firmware (what Handheld Daemon drives)
    msi_pl1: str | None = None
    msi_pl2: str | None = None
    msi_pl3: str | None = None
    # battery
    battery: str | None = None
    charge_limit: str | None = None
    # package temperature (m°C), for the temperature guard while thermald is paused (thermal.py)
    pkg_temp: str | None = None
    pkg_temp_sensor: str | None = None   # "x86_pkg_temp" (thermal zone) or "coretemp" (hwmon)


@dataclass
class Hardware:
    product: str
    model: dict
    known: bool
    kernel: str
    cpu_model: str
    gpu_driver: str | None
    paths: Paths
    model_id: str = ""      # the MODELS key that matched (board id), "" when unknown

    @property
    def model_key(self) -> str:
        """Key for per-model tables (PROFILES): the matched board id, else the raw product name."""
        return self.model_id or self.product

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


def _first(globpat: str) -> str | None:
    hits = sorted(glob.glob(globpat))
    return hits[0] if hits else None


def discover_paths() -> Paths:
    p = Paths()
    # GPU: the first Intel card with xe-style clock files, else i915-style
    for card in sorted(glob.glob("/sys/class/drm/card[0-9]")):
        vendor = sysfs.read(f"{card}/device/vendor")
        if vendor and vendor.lower() != "0x8086":
            continue
        # gt0 is the graphics GT; gt1 on Panther Lake is the media GT and is never touched
        xe = f"{card}/device/tile0/gt0/freq0" if os.path.isdir(f"{card}/device/tile0/gt0/freq0") else \
            _first(f"{card}/device/tile0/gt*/freq0")
        if xe:
            p.gpu_card = card
            for name in ("min_freq", "max_freq", "cur_freq", "rp0_freq", "rpe_freq", "rpn_freq", "power_profile"):
                fp = f"{xe}/{name}"
                if os.path.exists(fp):
                    setattr(p, f"gpu_{name}", fp)
            break
        if os.path.exists(f"{card}/gt_max_freq_mhz"):
            p.gpu_card = card
            p.gpu_min_freq = f"{card}/gt_min_freq_mhz"
            p.gpu_max_freq = f"{card}/gt_max_freq_mhz"
            p.gpu_cur_freq = f"{card}/gt_cur_freq_mhz" if os.path.exists(f"{card}/gt_cur_freq_mhz") else None
            p.gpu_rp0_freq = f"{card}/gt_RP0_freq_mhz" if os.path.exists(f"{card}/gt_RP0_freq_mhz") else None
            p.gpu_rpn_freq = f"{card}/gt_RPn_freq_mhz" if os.path.exists(f"{card}/gt_RPn_freq_mhz") else None
            break
    # CPU
    for name in ("max_perf_pct", "min_perf_pct", "no_turbo"):
        fp = f"/sys/devices/system/cpu/intel_pstate/{name}"
        if os.path.exists(fp):
            setattr(p, f"cpu_{name}", fp)
    if os.path.exists("/sys/devices/system/cpu/cpufreq/boost"):
        p.cpu_boost = "/sys/devices/system/cpu/cpufreq/boost"
    p.cpu_governor = sorted(glob.glob("/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor"))
    p.cpu_epp = sorted(glob.glob("/sys/devices/system/cpu/cpu[0-9]*/cpufreq/energy_performance_preference"))
    # RAPL package domain; the MMIO interface first, as PowerStation does (it is the one the SoC firmware honours on
    # recent Intel; the MSR one can be overridden by the platform)
    for d in sorted(glob.glob("/sys/class/powercap/intel-rapl-mmio:[0-9]")) + sorted(glob.glob("/sys/class/powercap/intel-rapl:[0-9]")):
        if (sysfs.read(f"{d}/name") or "").startswith("package"):
            p.rapl_package = d
            for c in sorted(glob.glob(f"{d}/constraint_[0-9]_name")):
                n = sysfs.read(c) or ""
                idx = c.rsplit("_", 2)[-2]
                limit = f"{d}/constraint_{idx}_power_limit_uw"
                if n == "long_term":
                    p.rapl_pl1 = limit
                    if os.path.exists(f"{d}/constraint_{idx}_max_power_uw"):
                        p.rapl_pl1_max = f"{d}/constraint_{idx}_max_power_uw"
                    if os.path.exists(f"{d}/constraint_{idx}_time_window_us"):
                        p.rapl_pl1_window = f"{d}/constraint_{idx}_time_window_us"
                elif n == "short_term":
                    p.rapl_pl2 = limit
            if os.path.exists(f"{d}/energy_uj"):
                p.rapl_energy = f"{d}/energy_uj"
            break
    if p.rapl_package:
        for d in sorted(glob.glob("/sys/class/powercap/intel-rapl:[0-9]")) + sorted(glob.glob("/sys/class/powercap/intel-rapl-mmio:[0-9]")):
            if d != p.rapl_package and (sysfs.read(f"{d}/name") or "").startswith("package"):
                for c in sorted(glob.glob(f"{d}/constraint_[0-9]_name")):
                    n = sysfs.read(c) or ""
                    idx = c.rsplit("_", 2)[-2]
                    if n == "long_term":
                        p.rapl_alt_pl1 = f"{d}/constraint_{idx}_power_limit_uw"
                    elif n == "short_term":
                        p.rapl_alt_pl2 = f"{d}/constraint_{idx}_power_limit_uw"
                if not os.path.exists(p.rapl_energy or "") and os.path.exists(f"{d}/energy_uj"):
                    p.rapl_energy = f"{d}/energy_uj"
                break
    # MSI firmware attributes (msi-wmi-platform), the paths Handheld Daemon writes
    base = "/sys/class/firmware-attributes/msi-wmi-platform/attributes"
    for attr, key in (("ppt_pl1_spl", "msi_pl1"), ("ppt_pl2_sppt", "msi_pl2"), ("ppt_pl3_fppt", "msi_pl3")):
        fp = f"{base}/{attr}/current_value"
        if os.path.exists(fp):
            setattr(p, key, fp)
    # battery
    for bat in sorted(glob.glob("/sys/class/power_supply/BAT*")):
        p.battery = bat
        if os.path.exists(f"{bat}/charge_control_end_threshold"):
            p.charge_limit = f"{bat}/charge_control_end_threshold"
        break
    p.pkg_temp, p.pkg_temp_sensor = find_pkg_temp()
    return p


def find_pkg_temp(sys_root: str = "/sys") -> tuple[str | None, str | None]:
    """The CPU package temperature: the x86_pkg_temp thermal zone (what thermald reads), else coretemp's
    "Package id 0" (its temp1 when no label says so)."""
    for z in sorted(glob.glob(f"{sys_root}/class/thermal/thermal_zone[0-9]*")):
        if sysfs.read(f"{z}/type") == "x86_pkg_temp" and os.path.exists(f"{z}/temp"):
            return f"{z}/temp", "x86_pkg_temp"
    for h in sorted(glob.glob(f"{sys_root}/class/hwmon/hwmon[0-9]*")):
        if sysfs.read(f"{h}/name") != "coretemp":
            continue
        for lab in sorted(glob.glob(f"{h}/temp[0-9]*_label")):
            if (sysfs.read(lab) or "").startswith("Package"):
                inp = lab[: -len("_label")] + "_input"
                if os.path.exists(inp):
                    return inp, "coretemp"
        if os.path.exists(f"{h}/temp1_input"):
            return f"{h}/temp1_input", "coretemp"
    return None, None


def match_model(board: str, product: str) -> tuple[str, dict | None]:
    """(MODELS key, row) for this machine's DMI names: board id first, then the product name."""
    for key in (board.strip(), product.strip()):
        if key in MODELS:
            return key, MODELS[key]
    return "", None


def detect() -> Hardware:
    product = (sysfs.read("/sys/class/dmi/id/product_name") or "").strip()
    board = (sysfs.read("/sys/class/dmi/id/board_name") or "").strip()
    model_id, model = match_model(board, product)
    known = model is not None
    if model is None:
        model = {"name": f"Unknown ({product or board or 'no DMI name'})", "soc": "?", "gpu": "?", "xmx": False,
                 "tdp": {"min": 5, "battery_max": 25, "plugged_max": 30, "sppt_max": 30}, "panel_hz": [60]}
    cpu_model = ""
    try:
        with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu_model = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    paths = discover_paths()
    gpu_driver = None
    if paths.gpu_card:
        drv = os.path.realpath(f"{paths.gpu_card}/device/driver")
        gpu_driver = os.path.basename(drv) if drv else None
    return Hardware(product=product, model=model, known=known, kernel=platform.release(), cpu_model=cpu_model,
                    gpu_driver=gpu_driver, paths=paths, model_id=model_id)


def capabilities(h: "Hardware", fan_kind: str | None = None) -> dict:
    """What this device can do, so ClawDeck only offers what works on it (maintainer, 2026-11-06: "identify the device
    first before presenting the options"). xmx: True / False from the model table; None on an unknown device (the XMX
    driver's own self-test decides). The MSI-only parts (face buttons, MSI fan tables) need an MSI Claw."""
    m = h.model
    vendor = m.get("vendor") if h.known else None
    return {
        "device": m.get("name"), "known": h.known, "vendor": vendor, "beta": bool(m.get("beta")) or not h.known,
        "xmx": m.get("xmx") if h.known else None,
        "fan": fan_kind, "charge_limit": bool(h.paths.charge_limit),
        "face_buttons": h.model_id == "MS-1T91",
        # gamescope runs the OXP3's OLED in HDR10, where the panel ignores its backlight: brightness is gamescope's
        # SDR-on-HDR level instead (screen.py)
        "hdr_brightness": bool(m.get("oled_hdr")) and h.known,
    }


def profiles_for(product: str) -> dict[str, dict]:
    return PROFILES.get(product, PROFILES["default"])


def tdp_range(model: dict, plugged: bool | None = None) -> tuple[int, int]:
    """The watts the TDP slider spans: the model's minimum to its maximum for this power source (8-35 W on the EX)."""
    lim = model["tdp"]
    return lim["min"], lim["plugged_max"] if plugged else lim["battery_max"]


ICD_DIRS = ("/usr/share/vulkan/icd.d", "/etc/vulkan/icd.d")


def intel_vulkan_lib() -> str | None:
    """The Intel Vulkan driver the loader would use: VK_DRIVER_FILES, else the installed Intel ICD json's
    library_path, else the usual library locations."""
    jsons = [j for j in os.environ.get("VK_DRIVER_FILES", "").split(":") if j]
    for d in ICD_DIRS:
        jsons += sorted(glob.glob(f"{d}/intel_icd*.json"))
    for j in jsons:
        m = re.search(r'"library_path"\s*:\s*"([^"]+)"', sysfs.read(j) or "")
        if m and "hasvk" not in m.group(1):
            lib = m.group(1) if os.path.isabs(m.group(1)) else os.path.join(os.path.dirname(j), m.group(1))
            if os.path.exists(lib):
                return lib
            for d in ("/usr/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/lib"):   # bare file name in the json
                if os.path.exists(os.path.join(d, os.path.basename(lib))):
                    return os.path.join(d, os.path.basename(lib))
    for lib in ("/usr/lib64/libvulkan_intel.so", "/usr/lib/x86_64-linux-gnu/libvulkan_intel.so", "/usr/lib/libvulkan_intel.so"):
        if os.path.exists(lib):
            return lib
    return None


MESA_RE = re.compile(rb"Mesa (\d+\.\d+\.\d+(?:-[0-9a-z.]+)?)")


def mesa_version() -> str | None:
    """Mesa version of the active Intel Vulkan driver: the "Mesa X.Y.Z" string in the library, else the rpm that
    owns it (Bazzite and Fedora). None when no Intel Vulkan driver is installed or neither source says."""
    lib = intel_vulkan_lib()
    if not lib:
        return None
    try:
        with open(lib, "rb") as f:
            m = MESA_RE.search(f.read())
        if m:
            return m.group(1).decode()
    except OSError:
        pass
    try:
        r = subprocess.run(["rpm", "-qf", "--qf", "%{VERSION}", lib], capture_output=True, text=True, timeout=5,
                           check=False)
        v = r.stdout.strip()
        if r.returncode == 0 and re.fullmatch(r"\d+\.\d+(\.\d+)?[0-9a-z.~-]*", v):
            return v
    except (OSError, subprocess.SubprocessError):
        pass
    return None
