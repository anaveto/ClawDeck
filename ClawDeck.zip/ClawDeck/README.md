<p align="center">
  <img src="assets/logo.png" alt="ClawDeck logo" width="200">
</p>

<h1 align="center">ClawDeck</h1>

<p align="center"><b>Everything an Intel MSI Claw needs on Linux, in one Decky plugin.<br>FSR 4.1.2 and XeSS on the XMX cores, XeSS frame generation with low latency, power, fans and the fixes,<br>all from Steam's Quick Access menu.</b></p>

<p align="center">
  <a href="https://github.com/IHulkSmashI/ClawDeck/releases"><img src="https://img.shields.io/github/v/release/IHulkSmashI/ClawDeck?include_prereleases&filter=v*&label=Latest%20Release&logo=github&color=7c3aed" alt="Latest release"></a>
  <a href="https://github.com/IHulkSmashI/ClawDeck/releases"><img src="https://img.shields.io/github/downloads/IHulkSmashI/ClawDeck/total?label=Downloads&color=4caf50" alt="Downloads"></a>
  <a href="https://github.com/IHulkSmashI/ClawDeck/commits/main"><img src="https://img.shields.io/github/last-commit/IHulkSmashI/ClawDeck?label=Last%20update" alt="Last update"></a>
  <br>
  <a href="#contents"><img src="https://img.shields.io/badge/Guide%20%26%20FAQ-Read%20the%20docs-2563eb?logo=readthedocs&logoColor=white" alt="Guide and FAQ"></a>
  <a href="https://github.com/IHulkSmashI/ClawDeck/discussions"><img src="https://img.shields.io/badge/Community-Discussions-5865F2?logo=github&logoColor=white" alt="Community: GitHub Discussions"></a>
  <a href="https://github.com/IHulkSmashI/ClawDeck/issues/new?template=game_report.yml"><img src="https://img.shields.io/badge/Report-a%20game-0ea5e9" alt="Report a game"></a>
  <br>
  <a href="https://ko-fi.com/gamervault"><img src="https://img.shields.io/badge/Support-Ko--fi-FF5E5B?logo=kofi&logoColor=white" alt="Support on Ko-fi"></a>
  <a href="LICENSE"><img src="https://img.shields.io/github/license/IHulkSmashI/ClawDeck?label=License&color=f0b429" alt="License"></a>
</p>

<p align="center">
  <img src="docs/img/game.png" alt="The Game tab: upscaling and frame generation for one game" width="32%">
  <img src="docs/img/power.png" alt="The Power tab: profile, TDP, Autotune, fan and battery" width="32%">
  <img src="docs/img/fixes.png" alt="The Fixes tab: VRR, face buttons, gyro, overlay watts, health" width="32%">
</p>

## One plugin, the whole Claw

- 🔥 **FSR 4.1.2 on the XMX cores.** AMD's best upscaler, rebuilt for Intel's AI cores. It comes with ClawDeck,
  nothing extra to download, and shows in DirectX 12 games with DLSS or FSR: the best image the Claw can get.
- ⚡ **XeSS 2 on XMX**, the real Intel path, not the slower DP4a fallback Linux gives you out of the box.
- 🎞️ **XeSS frame generation, 2x to 4x,** with **XeLL low latency always on**, so the extra frames don't cost you the
  feel.
- 🎮 **One tap per game.** Pick the game, the upscaler and frame generation, tap Install. ClawDeck installs a pinned,
  tested OptiScaler with the per-game fixes OptiScaler's developers publish, and adds REFramework to Capcom games.
  Uninstall puts every original file back.
- 🔋 **Power that works:** profiles from 8 to 35 W (Steam's own TDP slider does nothing on the Claw 8 EX),
  **Autotune** with a **target frame rate**: pick 30, 40, 60 fps and it holds it with the fewest watts, settles in about
  a minute, gives the watts back within seconds in a heavy scene, and holds what the full TDP gives when your target
  is out of reach. It stays out of emulators whose frame counter lies (xemu), and a temperature guard cools a
  hot spot by capping the CPU clock instead of cutting watts for everything. Plus fan curves and a battery charge
  limit.
- 🕹️ **ES-DE games too:** each game you start from ES-DE gets its own power pick and Autotune, not one limit for NES and
  PS3 alike.
- 🎯 **Gyro on the Claw 8 EX (beta):** one button turns on the EX's gyro for Steam Input (Kisenir's method).
- 🛠️ **The fixes Linux doesn't have yet:** the 30–120 Hz VRR range, the two MSI face buttons, real CPU, GPU and
  battery watts in the performance overlay, and a log flood that costs battery.
- 🎛️ **Tabs you switch with LB and RB:** Power, Game, Fixes and Setup, always on screen in Quick Access.

**Tested on** the MSI Claw 8 EX AI+ (Panther Lake, Arc B390) on Bazzite, mainly with CONTROL Resonant and Onimusha:
Way of the Sword, and by users on SteamOS. **Works on Bazzite, SteamOS and CachyOS:** ClawDeck only needs Decky
Loader, Steam's Game Mode and Proton, and XeSS on XMX works on Proton 11, Proton Experimental and GE-Proton (a Proton
installed as a system package, like CachyOS's proton-cachyos from pacman, can't be given the XMX file: pick one of
those three for XeSS and FSR 4.1.2 games). ClawDeck checks which handheld it's on first and only shows what that one can do:

| Device | What you get |
|---|---|
| MSI Claw 8 EX AI+ | Everything (tested) |
| MSI Claw 8 AI+, 7 AI+ | Everything; tell us how it runs |
| MSI Claw A1M, A8 | Power, fans and fixes (no XMX cores: XeSS runs on the regular graphics cores) |
| ONEXPLAYER 3 | **Beta:** XeSS, FSR 4.1.2 and frame gen on XMX, power, fan, charge limit, and a brightness control that works on its OLED |
| OneXPlayer X1 Air | **Beta:** XeSS, FSR 4.1.2 and frame gen on XMX, power, fan, charge limit |
| Acer Predator Atlas 8 | **Beta:** XeSS, FSR 4.1.2 and frame gen on XMX, power (Linux has no fan or charge-limit driver for it yet) |
| Other Intel Arc handhelds | XeSS on XMX and power where the chip allows it; ClawDeck shows only what it finds |

> **Beta.** Tried it? Tell us how your games run: [Feedback](#feedback).

---

## Contents

1. [Install](#install)
2. [Set up a game](#set-up-a-game)
3. [What's in the panel](#whats-in-the-panel)
4. [Troubleshooting](#troubleshooting)
5. [Known limits](#known-limits)
6. [Updates and safety](#updates-and-safety)
7. [Uninstall](#uninstall)
8. [Feedback](#feedback)
9. [Credits](#credits)

---

## Install

You need an Intel handheld (see the table above) on [Bazzite](https://bazzite.gg), SteamOS or
[CachyOS](https://cachyos.org) handheld edition. New to Linux? Our [step-by-step guide](docs/INSTALL-BAZZITE.md) goes
from Windows to Bazzite, with Windows staying on your Claw.

**1. Decky Loader.** On Bazzite: open the **Bazzite Portal** and tick **Decky Loader**. On SteamOS and CachyOS: the
installer from [decky.xyz](https://decky.xyz) (Desktop Mode). On SteamOS, set a password for the Konsole line below
once with `passwd`.

**2. ClawDeck.** Either way works:

- **From Game Mode, no terminal:** Quick Access → Decky → gear → **Developer mode** on → **Developer** → **Install
  plugin from URL**, and enter:
  ```
  https://github.com/IHulkSmashI/ClawDeck/releases/download/v0.2.0-beta.20/ClawDeck.zip
  ```
- **From Desktop Mode:** open **Konsole** and paste (asks for your password once; run it again to update):
  ```
  curl -fsSL https://raw.githubusercontent.com/IHulkSmashI/ClawDeck/main/tools/update-from-main.sh | bash
  ```

ClawDeck isn't in Decky's plugin store, so it won't show up there.

**3. First run.** In Game Mode, open Quick Access → ClawDeck. It shows **Set up ClawDeck**:

<p align="center"><img src="docs/img/first-run.png" alt="First run: install the XeSS XMX driver, then the VRR fix" width="40%"></p>

1. **Install the XeSS XMX driver** (about 260 MB, a minute or two).
2. **Install the VRR fix**, then **restart the Claw** once.
3. Tap **Done: show the panel**.

The face-button fix and the log fix apply on their own.

---

## Set up a game

1. **Quick Access → ClawDeck → Upscaling and frame generation**, and pick the game (the running one is picked for
   you).
2. Pick the **Upscaler** (XeSS 2, FSR 4.1.2 or FSR 4.1.2 Lite) and **Frame generation** (Off, 2x, 3x, 4x).
3. Tap **Install OptiScaler in this game**.
4. Start the game. The first start takes a minute or two longer while the XMX programs compile.
5. In the game's graphics menu, pick **DLSS** (or FSR if it has no DLSS) and turn on its **frame generation**, then
   **restart the game once**. OptiScaler swaps in what you picked; switching these while the game runs can crash it.
6. ClawDeck shows **✓ XMX cores used in the last launch** when it worked. For OptiScaler's own menu in game, press
   **Insert** (no keyboard: bind Insert to a back button in Steam's controller layout for that game).

To change something later: pick again and tap **Apply changes**, then restart the game.

**DLSS on an Intel chip?** The game's DLSS option is only the input: the game hands OptiScaler the data it would give
DLSS, and OptiScaler runs XeSS or FSR 4.1.2 on the XMX cores with it. FSR 4.1.2 comes with ClawDeck and shows for DirectX 12
games.

---

## What's in the panel

One panel in Quick Access with four tabs, switched with LB and RB: **Power**, **Game** (upscaling and frame
generation), **Fixes** and **Setup**. **Explain every control** (in Setup) says what each control does, why you'd use it and what it costs.

### Power

| Control | What it does |
|---|---|
| **Profile** | Battery saver, Battery, Balanced, Performance, Plugged, Max: the most power the game may use. |
| **TDP (W)** | The same limit, 8–35 W. Moving it makes a Custom profile. With Custom, **Set PL2 yourself** sets the short-boost limit, and the toast shows what the chip took. |
| **Autotune** | Holds a **target** frame rate (30–120 fps) with the fewest watts, with watts back within seconds when a heavy scene drops below it; a target out of reach gets what the full TDP gives. **Autotune max TDP** is the most watts it may use; while Autotune is on, that and the target take the place of the TDP slider, which is greyed out. At the screen's refresh rate, the target you start with, that is the most frames the max TDP gives in the running game, within 0.5 % (or the game's own wobble). Counts rendered frames, so frame generation doesn't fool it. Games without their own MangoHud log get their frame rate from Steam's overlay; xemu, which always shows 60 fps, keeps your limit, even when you pick a new target. Switch it off (or change anything under Advanced) and your pick goes back on the chip at once. Its log (`autotune.csv`) has frame times and slow frames, so a limit that's just too low shows up even when the fps looks full. |
| **Temperature guard** | Over 95 °C it caps the CPU's top clock when a few busy cores make the heat, and steps the watts down from what the chip draws otherwise; both come back once it's cool, also while Autotune is switched off. |
| **Fan** | Automatic (MSI), Quiet, Cooling, Extreme, Full speed, or your own curve; the panel shows the curve the fans follow now. |
| **Battery** | Charge limit: Off, 80 %, 90 % or Custom. Keeps the battery healthier on the charger. |
| **Advanced** | CPU boost, GPU clocks, GPU efficiency mode, CPU energy mode, Autotune's floor. |

### Upscaling and frame generation

The list shows only games ClawDeck can set up (DLSS, FSR or XeSS inside), with a tag for what each one runs. Non-Steam games you added to Steam and run through Proton show up too, with their own prefix if the shortcut sets `STEAM_COMPAT_DATA_PATH`.

<p align="center"><img src="docs/img/game-tags.png" alt="The game list with a tag for each game's upscaler and frame generation" width="40%"></p>

| Pick | What it means |
|---|---|
| **Upscaler** | XeSS 2 is Intel's own and the fastest. FSR 4.1.2 gives the best image; Lite is faster for a little less detail. All on the XMX cores. |
| **Frame generation** | XeSS frame generation: 2x adds one frame per rendered one, 3x two, 4x three. |
| **OptiScaler overlay** | OptiScaler's counter at the top right: the upscaler in use and "(XeFG)" while frame generation runs. |

On its own, ClawDeck keeps **XeLL low latency** on, gives **Capcom RE Engine games** the REFramework they need to
start, and applies each game's fixes from OptiScaler's compatibility list.

### Fixes

| Fix | What it does |
|---|---|
| **VRR fix 30–120 Hz** | The screen can do VRR from 30 Hz but tells the system 48, so games below 48 fps judder. One restart. 30 Hz is below MSI's official floor and some panels flicker there: if yours does, remove the fix. |
| **Face buttons** (Claw 8 EX) | Maps the two MSI buttons: left = Steam menu, right = Quick Access. |
| **Gyro (beta)** (Claw 8 EX) | Turns on the EX's gyro for Steam Input: downloads MSI's sensor-hub firmware (checked before it's installed), lets Linux read the gyro, and passes it to Steam as a Steam Deck gyro. Then a cold boot (shut down, power on) and recalibrate gyro in Steam. **Accelerometer too** is a separate toggle, off by default (it makes gyro aim worse). Remove undoes it. Bazzite for now. Method by Kisenir. |
| **Performance overlay** | Real watts in Steam's performance overlay: CPU, GPU (with a MangoHud that reads the GPU counter) and the battery. |
| **ES-DE** (when ES-DE is installed) | Each game you start from ES-DE gets its own power pick and Autotune. |
| **System log** | Stops a split-lock log flood that costs battery. |
| **Health check** | One line: all good, or what needs a look. |

### Setup

The XeSS XMX driver ([xess-xmx-linux](https://github.com/HHHHanasak1/xess-xmx-linux)), OptiScaler's state, a
self-test, **Export log to Desktop** for bug reports, and a **Diagnostics log** (off by default): one row a second of
power, temperature, battery, clocks and fans plus the controller's reports, so a bug report shows the seconds before a
problem. **Explain every control** and the **Full view** are here too.

---

## Troubleshooting

| Problem | What to do |
|---|---|
| **Black picture** (the HUD still shows) | Check **XMX cores used in the last launch**. Red: restart the game. FSR 4.1.2 needs the XMX cores; XeSS 2 still works without them. |
| **Locked at 30 fps, or 60 with frame generation** | … → Performance → turn **Enable VRR** off and on, and check **Fixes → VRR fix** is installed. |
| **3x/4x greyed out in the game's menu** | Normal: pick the multiplier in ClawDeck. OptiScaler's own menu offers up to what you picked. |
| **Autotune with frame generation measures low** | Autotune counts rendered frames, and frame generation caps them at the screen's refresh ÷ the multiplier. Pick an **Autotune target** in rendered fps (60 with 2x shows about 120), or let Autotune measure once with frame generation off. |
| **Gyro doesn't show after installing it** | Shut the Claw down fully and turn it on again (a restart isn't always enough for the sensor hub), then recalibrate gyro in Steam's controller settings. Still nothing: Fixes shows which part is missing; Export log and tell us. |
| **Crash when changing the upscaler or frame generation in the game** | Some games crash when these change mid-game. Quit, change it in ClawDeck, start again. |
| **"Put there by another tool"** under In this game now | ClawDeck never touches an OptiScaler it didn't install (Decky Framegen's, say). Remove that one first, then pick again. |
| **XeSS doesn't reach the XMX cores** ("XMX cores not used yet" after playing) | Per-game → **Debug logs for the next launch**, play a minute, quit, then Setup → **Export log to Desktop** and attach it to [an issue](https://github.com/IHulkSmashI/ClawDeck/issues/new/choose). The report then shows where XeSS stopped. |
| **Flicker or stutter with VRR on, gone with VRR off** | Your panel doesn't like 30 Hz (it's below MSI's official 48 Hz floor). Fixes → **Remove VRR fix**, restart, and keep VRR on: it still works from 48 Hz. |
| **Anything else** | Setup → **Export log to Desktop**, then [open an issue](https://github.com/IHulkSmashI/ClawDeck/issues/new/choose) with the file. |

## Known limits

- **No DLSS in The Witcher 3 (5.0 and newer)**: the game switches DLSS off when it sees Proton, before OptiScaler
  gets a say. Pick XeSS in its menu (OptiScaler takes XeSS too), or run it with GE-Proton 11-9 or newer, which hides
  Proton from the game.
- **Flicker in Capcom RE Engine games** (Onimusha, Resident Evil): a bug in Intel's Linux graphics driver (Mesa) that
  Intel is working on. The launch option `/WineDetectionEnabled:False` (after `%command%`) fixed it in some RE Engine
  games; if a game won't start with it, take it out.
- **Gyro:** the 8 EX has it as a beta (Fixes → Gyro, Bazzite only for now). The 7/8 AI+ need a tester with MSI's
  sensor-hub firmware for their model; no gyro there yet.
- **Four back buttons in Steam:** InputPlumber presents the Claw as a Steam Deck controller. The Claw's two land on
  two of them; Steam's controller test shows which.

---

## Updates and safety

- **Updating ClawDeck:** Setup → **Update to …** when a new version is out. Decky installs it, and your settings,
  the XMX driver and your game setups stay.
- **Pinned and checked.** Every download (OptiScaler, REFramework, FSR 4.1.2) is a tested version with
  its sha256 in [`assets/versions.json`](assets/versions.json). Nothing updates until we've tested it on a Claw; then
  your games show **Update OptiScaler to X**.
- **The game's own files are backed up** before OptiScaler replaces them, and **Uninstall OptiScaler from this game**
  puts every original back.
- **Every system change is revertible.** Power changes end with the game, and everything is undone when ClawDeck is
  removed.

---

## Uninstall

1. For each game you set up: ClawDeck → the game → **Uninstall OptiScaler from this game**.
2. **Fixes:** remove the VRR fix, the face-button fix and the gyro if you want them gone.
3. Decky → gear → ClawDeck → **Uninstall**. Power goes back to the firmware's own and the XMX driver comes out.
4. Optional: delete `~/.local/share/clawdeck` and `~/fsr4-xmx` (ClawDeck's downloads, about 1 GB).

---

## Feedback

ClawDeck is in beta, and what you see on your Claw decides what we work on next:

- **How a game runs:** [Game report](https://github.com/IHulkSmashI/ClawDeck/issues/new?template=game_report.yml), a
  one-page form.
- **Ideas:** [Discussions → Ideas](https://github.com/IHulkSmashI/ClawDeck/discussions/categories/ideas).
- **Questions:** [Discussions → Q&A](https://github.com/IHulkSmashI/ClawDeck/discussions/categories/q-a).
- **Something broke:** [Bug report](https://github.com/IHulkSmashI/ClawDeck/issues/new?template=bug_report.md), with
  the file from Setup → Export log.

ClawDeck is free. If you'd like to chip in: [ko-fi.com/gamervault](https://ko-fi.com/gamervault).

## Credits

A big thank you to [HHHHanasak1](https://github.com/HHHHanasak1), whose
[xess-xmx-linux](https://github.com/HHHHanasak1/xess-xmx-linux) puts XeSS on the XMX cores under Linux.

Thanks to Kisenir (r/MSIClaw), who found how to get the Claw 8 EX's gyro working on Linux and let ClawDeck use his
method and code.

Thanks also to [ClawTweaks](https://github.com/enterTheVoidCode/ClawTweaks) and
[OptiClick](https://github.com/onehoon/OptiClick) for the inspiration.

Open-source licenses of the parts ClawDeck uses: [CREDITS.md](CREDITS.md). Contributing: [CONTRIBUTING.md](CONTRIBUTING.md).

[AGPLv3](LICENSE) (see [LICENSING.md](LICENSING.md)). A community project, not affiliated with MSI, Valve, Intel, AMD
or Microsoft. "Claw" is a trademark of MSI.
